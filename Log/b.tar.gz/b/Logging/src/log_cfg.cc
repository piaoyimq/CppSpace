/*---------------------------------------------------------------------------------------------------------------------
 * Template Id: 20041119
 *
 * Copyright (C) 2015 by Ericsson AB
 * S - 125 26  STOCKHOLM
 * SWEDEN, tel int +46 10 719 00 00
 *
 * The copyright to the computer program herein is the property of Ericsson AB. The program may be used and/or copied
 * only with the written permission from Ericsson AB, or in accordance with the terms and conditions stipulated in the
 * agreement/contract under which the program has been supplied.
 *
 * All rights reserved.
 */

#include "app/Logging/include/log_cfg.h"
/*-------------------------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------------------------------------*/
