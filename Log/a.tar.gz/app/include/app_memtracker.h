#ifndef APP_INCLUDE_APP_MEMTRACKER_H_
#define APP_INCLUDE_APP_MEMTRACKER_H_
/*---------------------------------------------------------------------------------------------------------------------
 * Copyright (C) 2000-2015 by Ericsson AB
 *
 * Address:
 * Torshamnsgatan 21
 * 164 83 Kista
 * SWEDEN
 *
 * Telephone: +46 10 719 00 00
 *
 * All Rights Reserved. No part of this software may be reproduced in
 * any form without the written permission of the copyright owner.
 *-------------------------------------------------------------------------------------------------------------------*/

void memTrackerInit();

#endif /* APP_INCLUDE_APP_MEMTRACKER_H_ */
